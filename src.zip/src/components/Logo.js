import React from "react";

export const Logo = () => {
    return(
        <h1 id="logo"><i className='bx bxs-paper-plane' ></i> Axis Bank</h1>
    )
}
