import React from 'react';
import './App.css';
import { Authenticate } from './components/Authenticate';

function App() {
  return (
    <Authenticate />
  );
}

export default App;
