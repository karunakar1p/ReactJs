const DATA = [
    {
        email: "karuna@gmail.com",
        password: "abc123",
        fullname: "Karuna Account",
        type: "Savings Account",
        number: "47290539123",
        balance: 100000,
        isAdmin: true, 
        transactions: []
    },
    {
        email: "mounisha@gmail.com",
        password: "abc123",
        fullname: "Mounisha",
        type: "Savings Account",
        number: "47290539481",
        balance: 1029300,
        isAdmin: true, 
        transactions: []
    },
    {
        email: "Sonika@gmail.com",
        password: "abc123",
        fullname: "Sonika",
        type: "Savings Account",
        number: "47290539482",
        balance: 392830.22,
        isAdmin: false, 
        budget: [
            {
                title: "Tuition fee",
                amount: 12000
            },
            {
                title: "Food take out during the pandemic",
                amount: 4000
            }
        ], 
        transactions: [
            {
                title: "Fund transfer", 
                amount: 2000,
                type: "debit", 
                date: "October 1, 2021"
            }, 
            {
                title: "Withdraw", 
                amount: 10000, 
                type: "debit",
                date: "October 1, 2021"
            }
        ]
    },
    
];

export default DATA;
